package ghumover2



class MessageController

{
    static responseFormats = ['json', 'xml']



}
