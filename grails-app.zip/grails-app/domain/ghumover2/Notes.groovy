package ghumover2

class Notes {
String name

    static constraints = {
    }
}
