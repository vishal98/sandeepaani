package ghumover2

import java.sql.Timestamp;

import ghumover2.Student;
import ghumover2.Teacher

class Student_Marks {
	
	Student student
	ghumover2.Subject Subject
	ghumover2.Exam Exam
	Integer Score
	Integer Marks
	String description
	Teacher createdByUserId
	Timestamp createdDatetime
	Timestamp lastModifiedDatetime
	String lastModifiedBy
	
	
	
	
	

    static constraints = {
    }
}
