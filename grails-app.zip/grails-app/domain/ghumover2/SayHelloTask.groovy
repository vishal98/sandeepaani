package ghumover2

class SayHelloTask implements Task {

	@Override
	public void executeTask() {
		// TODO Auto-generated method stub

	}

}
