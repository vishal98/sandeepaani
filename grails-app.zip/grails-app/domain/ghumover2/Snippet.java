package ghumover2;

public class Snippet {
	public static void main(String[] args) {
		//schoole_name
	}
}

