package ghumover2

class Emplyee {
	String firstName
	String lastName
	

   /* static constraints = {
    }*/
}
