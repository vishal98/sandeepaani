package ghumover2

class Success {
	int success
	int failure
}
