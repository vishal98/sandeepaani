package ghumover2
import java.sql.Timestamp

class MonthOfYear
{
    int monthOfYearId
    String monthOfyearName
    Timestamp createdDate
}