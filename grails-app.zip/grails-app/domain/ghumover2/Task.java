package ghumover2;

public interface Task {
	void executeTask();

}
