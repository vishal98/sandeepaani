package ghumover2

class Sibling {
    static  belongTo = Student
    String name
    String gender
    String grade
    static constraints = {
    }
}
