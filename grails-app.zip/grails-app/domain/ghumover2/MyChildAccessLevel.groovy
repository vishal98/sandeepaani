package ghumover2

class MyChildAccessLevel {

    static constraints = {
    }
}
