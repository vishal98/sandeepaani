package ghumover2

class CodeLookUp {
	
	String type
	String value
	String code

    static constraints = {
    }
}
