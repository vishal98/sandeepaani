package ghumover2
class PushBotApi {
   
	String tokens
	String platform 
	String msg
	String sound 
	 String badge 
	  String payload 
	
   
}
