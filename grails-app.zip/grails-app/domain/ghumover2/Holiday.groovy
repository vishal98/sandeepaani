package ghumover2

class Holiday {

    String holiday_description
    static constraints = {
    }
}
