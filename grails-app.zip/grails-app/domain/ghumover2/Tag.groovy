package ghumover2

class Tag {

	int tagId
	String description
    static constraints = {
    }
}
